package com.fis.booklib.Controller;

import com.fis.booklib.Model.Book;
import com.fis.booklib.dao.BookDao;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by e1078815 on 9/20/2020.
 */

@RestController
@RequestMapping(path = "book")
public class BookInfoController {
    BookDao bookDao = new BookDao();

    @GetMapping(path = "AllBooks", produces = "application/json")
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        return books;
    }

    @GetMapping(path = "{id}", produces = "application/json")
    public Book getBookDetail(@PathVariable int id) {
        System.out.println("Getting Book" + id);
        Book book = new Book();
        book.setId(id);
        book.setName("Java In Action");
        book.setAuthor("James");
        book.setAvailableCopies(9);
        book.setTotalCopies(10);
        return book;
    }

    @GetMapping(path = "{id}", produces = "application/json")
    public Book updateBook(@PathVariable int id, int availableCopies) {
        System.out.println("Getting Book" + id);
        //Get the Book from dB.
        Book book = bookDao.getBook(id);
        book.setAvailableCopies(availableCopies);
        bookDao.persistBook(book);

        return book;
    }



}
