package com.fis.booklib.Model;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by e1078815 on 9/17/2020.
 */

@Getter
@Setter
public class Book {
    private int id;
    private String name;
    private String author;
    private int totalCopies;
    private int availableCopies;
}
