package com.fis.booklib.dao;

import com.fis.booklib.Model.Book;

/**
 * Created by e1078815 on 9/28/2020.
 */
public class BookDao {

    public Book getBook (int id) {
        Book book = null;
        //Oracle Template
        //Book book = em.findBook(id);
        return book;
    }

    public void persistBook(Book book) {
        //em.persist(book);
    }
}
