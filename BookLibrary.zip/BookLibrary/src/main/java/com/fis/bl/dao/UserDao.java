package com.fis.bl.dao;

import com.fis.bl.entity.User;

/**
 * Created by e1078815 on 9/14/2020.
 */
public class UserDao {

    public boolean checkUser(String userName) {
        //Oracle Template
        //OracleTemplate.find(User.class, userName);
        return true;
    }

    public User getUser(String userName) {
        return new User();
    }
}
