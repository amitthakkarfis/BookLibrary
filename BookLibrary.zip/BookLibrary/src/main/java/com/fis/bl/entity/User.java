package com.fis.bl.entity;



/**
 * Created by e1078815 on 9/14/2020.
 */

//@Entity
public class User {
    //private @Id @GeneratedValue
    Long id;
    String name;
    String userName;
    String email;
    String password;
}
