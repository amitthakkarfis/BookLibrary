package com.fis.bl.com.fis.controller;

import com.fis.bl.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

/**
 * Created by e1078815 on 9/14/2020.
 */
@RestController()
@RequestMapping("login")
public class LoginController {


    UserDao userDao = new UserDao();

    @GetMapping(path = "/checkUser/{userName}", produces = "application/json")
    public com.fis.bl.entity.User checkUser(@PathVariable String userName) {
        if (userDao.checkUser(userName)) {
            return userDao.getUser(userName);
        }
        return null;
    }
}
