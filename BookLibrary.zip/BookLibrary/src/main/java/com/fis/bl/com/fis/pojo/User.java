package com.fis.bl.com.fis.pojo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Bean;

/**
 * Created by e1078815 on 9/14/2020.
 */
@Getter
@Setter
public class User {
    private String fullName;
    private Long phoneNo;
    private String userName;
}
