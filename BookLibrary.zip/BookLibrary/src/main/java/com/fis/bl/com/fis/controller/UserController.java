package com.fis.bl.com.fis.controller;

import com.fis.bl.com.fis.pojo.User;
import org.springframework.web.bind.annotation.*;

/**
 * Created by e1078815 on 9/27/2020.
 */
@RestController
@RequestMapping("user")
public class UserController {

    @PostMapping("/createUser")
    public void createUser(@RequestBody User newUser) {

    }

    @PostMapping("/updateUser")
    public void updateUser() {

    }

    @GetMapping(path = "/deleteUser/{userID}", produces= "application/json")
    public String deleteUser(@PathVariable long userId) {

        return "Success";
    }

}
