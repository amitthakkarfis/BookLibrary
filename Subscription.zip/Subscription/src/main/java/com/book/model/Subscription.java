package com.book.model;

import java.util.Date;

/**
 * Created by e1078815 on 9/17/2020.
 */

public class Subscription {
    int bookId;
    int userId;
    Date subscribeDate;
    Date returnDate;
}
