package com.book.model;

/**
 * Created by e1078815 on 9/28/2020.
 */
public class User {
}
