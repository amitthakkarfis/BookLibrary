package com.book.controller;

import com.book.model.Book;
import com.book.model.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * Created by e1078815 on 9/17/2020.
 */
@RestController
@RequestMapping(path = "BookSubscription")
public class BookSubscriptionController {

    @GetMapping(path = "AllBooks", produces = "application/json")
    public Book getAllBooks() {
        RestTemplate restTemplate = new RestTemplate();
        Book book = restTemplate.getForObject("http://BookService/book", Book.class);
        return book;
    }

    @GetMapping(path = "issueBook", produces = "application/json")
    public String issueBook(@PathVariable Long bookId, @PathVariable String userName) {
        String status = "Book Not issued";
        RestTemplate restTemplate = new RestTemplate();
        User user = restTemplate.getForObject("http://UserService/login/checkUser/{userName}"+userName, User.class);
        if (user != null) {
            Book book = restTemplate.getForObject("http://BookService/book/"+bookId, Book.class);
            if (book.getAvailableCopies() > 0) {
                //Add Subscription
                //Update Book
                status = "Book Issued";
            }
        } else {
            status = "User is not valid";
        }

        return status;
    }


}
